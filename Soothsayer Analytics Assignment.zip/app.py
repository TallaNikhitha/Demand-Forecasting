from flask import Flask, request, render_template, send_file
from prophet import Prophet
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import io
import base64

app = Flask(__name__)

# Load the data
transactional_data_01 = pd.read_csv('Transactional_data_retail_01.csv')
transactional_data_02 = pd.read_csv('Transactional_data_retail_02.csv')

# Merge and process the datasets
transactional_data = pd.concat([transactional_data_01, transactional_data_02], ignore_index=True)
transactional_data['InvoiceDate'] = pd.to_datetime(transactional_data['InvoiceDate'], errors='coerce')
transactional_data['TotalSales'] = transactional_data['Quantity'] * transactional_data['Price']

# Identify top 10 products by total sales
top_products = transactional_data.groupby('StockCode')['TotalSales'].sum().reset_index()
top_10_products = top_products.sort_values(by='TotalSales', ascending=False).head(10)
top_10_product_codes = top_10_products['StockCode'].tolist()

# Set up the main route for the home page
@app.route('/')
def home():
    return render_template('index.html', product_codes=top_10_product_codes)

# Function to generate the combined plot for historical and forecasted demand
@app.route('/forecast', methods=['POST'])
def forecast():
    product_code = request.form['product_code']
    weeks = 15  # Forecasting for the next 15 weeks

    # Prepare the data for the selected product
    product_sales_data = transactional_data[transactional_data['StockCode'] == product_code]
    product_sales_data.set_index('InvoiceDate', inplace=True)
    product_sales_data = product_sales_data.resample('W')['TotalSales'].sum().reset_index()
    product_sales_data.columns = ['ds', 'y']

    # Create and fit the Prophet model
    model = Prophet()
    model.fit(product_sales_data)

    # Forecast for the next 15 weeks
    future = model.make_future_dataframe(periods=weeks, freq='W')
    forecast = model.predict(future)

    # Plot the combined time series for historical and forecasted demand
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(product_sales_data['ds'], product_sales_data['y'], label='Historical Demand', marker='o')
    ax.plot(forecast['ds'], forecast['yhat'], label='Forecasted Demand', linestyle='--', marker='x')
    ax.set_title(f'Demand Overview for {product_code}')
    ax.set_xlabel('Date')
    ax.set_ylabel('Demand')
    ax.legend()

    # Save the plot to a BytesIO object
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode('utf8')

    # Calculate training and test error histograms (for illustrative purposes)
    train_errors = product_sales_data['y'] - model.predict(product_sales_data)['yhat']
    test_errors = forecast['yhat'] - product_sales_data['y'].mean()  # Simulated test errors

    # Plot error histograms
    fig_error, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    sns.histplot(train_errors, kde=True, ax=ax1, color='green')
    ax1.set_title('Training Error Distribution')
    sns.histplot(test_errors, kde=True, ax=ax2, color='red')
    ax2.set_title('Testing Error Distribution')

    # Save the error histograms to a BytesIO object
    error_img = io.BytesIO()
    plt.savefig(error_img, format='png')
    error_img.seek(0)
    error_plot_url = base64.b64encode(error_img.getvalue()).decode('utf8')

    # Render the forecast page with both plots
    return render_template('forecast.html', plot_url=plot_url, error_plot_url=error_plot_url, product_code=product_code)

if __name__ == '__main__':
    app.run(debug=True)
